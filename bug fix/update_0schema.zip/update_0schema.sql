ALTER TABLE purchaseorder MODIFY grossTotal DECIMAL(14, 6);
ALTER TABLE purchaseorder MODIFY netTotal DECIMAL(14, 6);
ALTER TABLE purchaseorder MODIFY totalPrcntDscnt DECIMAL(14, 6);
ALTER TABLE purchaseorder MODIFY totalAmtDscnt DECIMAL(14, 6);

ALTER TABLE grpo MODIFY grossTotal DECIMAL(14, 6);
ALTER TABLE grpo MODIFY netTotal DECIMAL(14, 6);
ALTER TABLE grpo MODIFY totalPrcntDscnt DECIMAL(14, 6);
ALTER TABLE grpo MODIFY totalAmtDscnt DECIMAL(14, 6);

ALTER TABLE inventorytransfer MODIFY grossTotal DECIMAL(14, 6);
ALTER TABLE inventorytransfer MODIFY netTotal DECIMAL(14, 6);
ALTER TABLE inventorytransfer MODIFY totalPrcntDscnt DECIMAL(14, 6);
ALTER TABLE inventorytransfer MODIFY totalAmtDscnt DECIMAL(14, 6);

ALTER TABLE goodsreturn MODIFY grossTotal DECIMAL(14, 6);
ALTER TABLE goodsreturn MODIFY netTotal DECIMAL(14, 6);
ALTER TABLE goodsreturn MODIFY totalPrcntDscnt DECIMAL(14, 6);
ALTER TABLE goodsreturn MODIFY totalAmtDscnt DECIMAL(14, 6);

ALTER TABLE salesinvoice MODIFY grossTotal DECIMAL(14, 6);
ALTER TABLE salesinvoice MODIFY netTotal DECIMAL(14, 6);
ALTER TABLE salesinvoice MODIFY totalPrcntDscnt DECIMAL(14, 6);
ALTER TABLE salesinvoice MODIFY totalAmtDscnt DECIMAL(14, 6);

ALTER TABLE salesreturn MODIFY grossTotal DECIMAL(14, 6);
ALTER TABLE salesreturn MODIFY netTotal DECIMAL(14, 6);
ALTER TABLE salesreturn MODIFY totalPrcntDscnt DECIMAL(14, 6);
ALTER TABLE salesreturn MODIFY totalAmtDscnt DECIMAL(14, 6);

-- MODIFY ROW items COLUMNS
ALTER TABLE purchaseorder_item MODIFY realBsNetPrchsPrc DECIMAL(14, 6);
ALTER TABLE purchaseorder_item MODIFY realBsGrossPrchsPrc DECIMAL(14, 6);
ALTER TABLE purchaseorder_item MODIFY realNetPrchsPrc DECIMAL(14, 6);
ALTER TABLE purchaseorder_item MODIFY realGrossPrchsPrc DECIMAL(14, 6);
ALTER TABLE purchaseorder_item MODIFY qty DECIMAL(14, 6);
ALTER TABLE purchaseorder_item MODIFY qtyPrPrchsUoM DECIMAL(14, 6);
ALTER TABLE purchaseorder_item MODIFY prcntDscnt DECIMAL(14, 6);
ALTER TABLE purchaseorder_item MODIFY amtDscnt DECIMAL(14, 6);
ALTER TABLE purchaseorder_item MODIFY netPrchsPrc DECIMAL(14, 6);
ALTER TABLE purchaseorder_item MODIFY grossPrchsPrc DECIMAL(14, 6);
ALTER TABLE purchaseorder_item MODIFY rowNetTotal DECIMAL(14, 6);
ALTER TABLE purchaseorder_item MODIFY rowGrossTotal DECIMAL(14, 6);

ALTER TABLE grpo_item MODIFY realBsNetPrchsPrc DECIMAL(14, 6);
ALTER TABLE grpo_item MODIFY realBsGrossPrchsPrc DECIMAL(14, 6);
ALTER TABLE grpo_item MODIFY realNetPrchsPrc DECIMAL(14, 6);
ALTER TABLE grpo_item MODIFY realGrossPrchsPrc DECIMAL(14, 6);
ALTER TABLE grpo_item MODIFY qty DECIMAL(14, 6);
ALTER TABLE grpo_item MODIFY qtyPrPrchsUoM DECIMAL(14, 6);
ALTER TABLE grpo_item MODIFY prcntDscnt DECIMAL(14, 6);
ALTER TABLE grpo_item MODIFY amtDscnt DECIMAL(14, 6);
ALTER TABLE grpo_item MODIFY netPrchsPrc DECIMAL(14, 6);
ALTER TABLE grpo_item MODIFY grossPrchsPrc DECIMAL(14, 6);
ALTER TABLE grpo_item MODIFY rowNetTotal DECIMAL(14, 6);
ALTER TABLE grpo_item MODIFY rowGrossTotal DECIMAL(14, 6);

ALTER TABLE inventorytransfer_item MODIFY realBsNetPrchsPrc DECIMAL(14, 6);
ALTER TABLE inventorytransfer_item MODIFY realBsGrossPrchsPrc DECIMAL(14, 6);
ALTER TABLE inventorytransfer_item MODIFY realNetPrchsPrc DECIMAL(14, 6);
ALTER TABLE inventorytransfer_item MODIFY realGrossPrchsPrc DECIMAL(14, 6);
ALTER TABLE inventorytransfer_item MODIFY qty DECIMAL(14, 6);
ALTER TABLE inventorytransfer_item MODIFY qtyPrPrchsUoM DECIMAL(14, 6);
ALTER TABLE inventorytransfer_item MODIFY prcntDscnt DECIMAL(14, 6);
ALTER TABLE inventorytransfer_item MODIFY amtDscnt DECIMAL(14, 6);
ALTER TABLE inventorytransfer_item MODIFY netPrchsPrc DECIMAL(14, 6);
ALTER TABLE inventorytransfer_item MODIFY grossPrchsPrc DECIMAL(14, 6);
ALTER TABLE inventorytransfer_item MODIFY rowNetTotal DECIMAL(14, 6);
ALTER TABLE inventorytransfer_item MODIFY rowGrossTotal DECIMAL(14, 6);

ALTER TABLE goodsreturn_item MODIFY realBsNetPrchsPrc DECIMAL(14, 6);
ALTER TABLE goodsreturn_item MODIFY realBsGrossPrchsPrc DECIMAL(14, 6);
ALTER TABLE goodsreturn_item MODIFY realNetPrchsPrc DECIMAL(14, 6);
ALTER TABLE goodsreturn_item MODIFY realGrossPrchsPrc DECIMAL(14, 6);
ALTER TABLE goodsreturn_item MODIFY qty DECIMAL(14, 6);
ALTER TABLE goodsreturn_item MODIFY qtyPrPrchsUoM DECIMAL(14, 6);
ALTER TABLE goodsreturn_item MODIFY prcntDscnt DECIMAL(14, 6);
ALTER TABLE goodsreturn_item MODIFY amtDscnt DECIMAL(14, 6);
ALTER TABLE goodsreturn_item MODIFY netPrchsPrc DECIMAL(14, 6);
ALTER TABLE goodsreturn_item MODIFY grossPrchsPrc DECIMAL(14, 6);
ALTER TABLE goodsreturn_item MODIFY rowNetTotal DECIMAL(14, 6);
ALTER TABLE goodsreturn_item MODIFY rowGrossTotal DECIMAL(14, 6);

ALTER TABLE salesinvoice_item MODIFY qtyPrSaleUoM DECIMAL(14, 6);
ALTER TABLE salesinvoice_item MODIFY netPrchsPrc DECIMAL(14, 6);
ALTER TABLE salesinvoice_item MODIFY grossPrchsPrc DECIMAL(14, 6);
ALTER TABLE salesinvoice_item MODIFY realBsNetSalePrc DECIMAL(14, 6);
ALTER TABLE salesinvoice_item MODIFY realBsGrossSalePrc DECIMAL(14, 6);
ALTER TABLE salesinvoice_item MODIFY qty DECIMAL(14, 6);
ALTER TABLE salesinvoice_item MODIFY prcntDscnt DECIMAL(14, 6);
ALTER TABLE salesinvoice_item MODIFY amtDscnt DECIMAL(14, 6);
ALTER TABLE salesinvoice_item MODIFY netSalePrc DECIMAL(14, 6);
ALTER TABLE salesinvoice_item MODIFY grossSalePrc DECIMAL(14, 6);
ALTER TABLE salesinvoice_item MODIFY rowNetTotal DECIMAL(14, 6);
ALTER TABLE salesinvoice_item MODIFY rowGrossTotal DECIMAL(14, 6);

ALTER TABLE salesreturn_item MODIFY qtyPrSaleUoM DECIMAL(14, 6);
ALTER TABLE salesreturn_item MODIFY netPrchsPrc DECIMAL(14, 6);
ALTER TABLE salesreturn_item MODIFY grossPrchsPrc DECIMAL(14, 6);
ALTER TABLE salesreturn_item MODIFY realBsNetSalePrc DECIMAL(14, 6);
ALTER TABLE salesreturn_item MODIFY realBsGrossSalePrc DECIMAL(14, 6);
ALTER TABLE salesreturn_item MODIFY qty DECIMAL(14, 6);
ALTER TABLE salesreturn_item MODIFY prcntDscnt DECIMAL(14, 6);
ALTER TABLE salesreturn_item MODIFY amtDscnt DECIMAL(14, 6);
ALTER TABLE salesreturn_item MODIFY netSalePrc DECIMAL(14, 6);
ALTER TABLE salesreturn_item MODIFY grossSalePrc DECIMAL(14, 6);
ALTER TABLE salesreturn_item MODIFY rowNetTotal DECIMAL(14, 6);
ALTER TABLE salesreturn_item MODIFY rowGrossTotal DECIMAL(14, 6);

/* Update purchase order header */
UPDATE purchaseorder
INNER JOIN (
  SELECT docId, ROUND(SUM(rowGrossTotal), 2) AS total
  FROM purchaseorder_item
  GROUP BY docId
) AS purchaseorder_item ON purchaseorder.docId = purchaseorder_item.docId
SET purchaseorder.grossTotal = purchaseorder_item.total;

UPDATE purchaseorder
INNER JOIN (
  SELECT docId, ROUND(SUM(rowNetTotal), 2) AS rowNetTotal
  FROM purchaseorder_item
  GROUP BY docId
) AS purchaseorder_item ON purchaseorder.docId = purchaseorder_item.docId
SET purchaseorder.netTotal = purchaseorder_item.rowNetTotal;

/* Update grpo row amounts */
UPDATE grpo_item SET rowNetTotal = qty * qtyPrPrchsUoM * netPrchsPrc;
UPDATE grpo_item SET rowGrossTotal = qty * qtyPrPrchsUoM * grossPrchsPrc;

/* Update grpo header */
UPDATE grpo 
INNER JOIN (
  SELECT docId, ROUND(SUM(rowGrossTotal), 2) AS total
  FROM grpo_item
  GROUP BY docId
) grpo_item ON grpo.docId = grpo_item.docId
SET grpo.grossTotal = grpo_item.total;

UPDATE grpo 
INNER JOIN (
  SELECT docId, ROUND(SUM(rowNetTotal), 2) AS rowNetTotal
  FROM grpo_item
  GROUP BY docId
) grpo_item ON grpo.docId = grpo_item.docId
SET grpo.netTotal = grpo_item.rowNetTotal;


UPDATE inventorytransfer
INNER JOIN (
  SELECT docId, ROUND(SUM(rowGrossTotal), 2) AS rowGrossTotal
  FROM inventorytransfer_item
  GROUP BY docId
) AS inventorytransfer_item ON inventorytransfer.docId = inventorytransfer_item.docId
SET inventorytransfer.grossTotal = inventorytransfer_item.rowGrossTotal;

UPDATE inventorytransfer
INNER JOIN (
  SELECT docId, ROUND(SUM(rowNetTotal), 2) AS rowNetTotal
  FROM inventorytransfer_item
  GROUP BY docId
) AS inventorytransfer_item ON inventorytransfer.docId = inventorytransfer_item.docId
SET inventorytransfer.netTotal = inventorytransfer_item.rowNetTotal;

/* let's create new tables for the module */

CREATE TABLE `deliveryreceipt` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `docId` VARCHAR(21) NOT NULL,
  `warehouse` VARCHAR(16) NOT NULL,
  `postingDate` DATE NOT NULL,
  `remarks1` VARCHAR(500) DEFAULT NULL,
  `remarks2` VARCHAR(500) DEFAULT NULL,
  `totalPrcntDscnt` DECIMAL(14,6) DEFAULT NULL,
  `totalAmtDscnt` DECIMAL(14,6) DEFAULT NULL,
  `netTotal` DECIMAL(14,6) DEFAULT NULL,
  `grossTotal` DECIMAL(14,6) DEFAULT NULL,
  `createDate` DATETIME NOT NULL,
  `createdBy` INT(2) NOT NULL,
  `updateDate` DATETIME DEFAULT NULL,
  `updatedBy` INT(2) DEFAULT NULL,
  `exported` TINYINT(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `docId` (`docId`),
  KEY `createdBy` (`createdBy`),
  KEY `updatedBy` (`updatedBy`),
  KEY `warehouse` (`warehouse`),
  CONSTRAINT `deliveryreceipt_ibfk_1` FOREIGN KEY (`warehouse`) REFERENCES `warehouse` (`code`),
  CONSTRAINT `deliveryreceipt_ibfk_2` FOREIGN KEY (`updatedBy`) REFERENCES `users` (`user_id`),
  CONSTRAINT `deliveryreceipt_ibfk_3` FOREIGN KEY (`createdBy`) REFERENCES `users` (`user_id`)
) ENGINE=INNODB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

CREATE TABLE `deliveryreceipt_item` (
  `docId` VARCHAR(21) NOT NULL,
  `indx` INT(11) NOT NULL,
  `vendorCode` VARCHAR(15) NOT NULL,
  `vendorName` VARCHAR(100) DEFAULT NULL,
  `itemCode` VARCHAR(15) NOT NULL,
  `description` VARCHAR(250) DEFAULT NULL,
  `warehouse` VARCHAR(16) NOT NULL,
  `vatable` ENUM('Y','N') NOT NULL,
  `realBsNetPrchsPrc` DECIMAL(14,6) DEFAULT NULL,
  `realBsGrossPrchsPrc` DECIMAL(14,6) DEFAULT NULL,
  `realNetPrchsPrc` DECIMAL(14,6) DEFAULT NULL,
  `realGrossPrchsPrc` DECIMAL(14,6) DEFAULT NULL,
  `qty` DECIMAL(14,6) DEFAULT NULL,
  `baseUoM` ENUM('Y','N') NOT NULL,
  `qtyPrPrchsUoM` DECIMAL(14,6) DEFAULT NULL,
  `prcntDscnt` DECIMAL(14,6) DEFAULT NULL,
  `amtDscnt` DECIMAL(14,6) DEFAULT NULL,
  `netPrchsPrc` DECIMAL(14,6) DEFAULT NULL,
  `grossPrchsPrc` DECIMAL(10,6) NOT NULL,
  `rowNetTotal` DECIMAL(10,6) NOT NULL,
  `rowGrossTotal` DECIMAL(14,6) DEFAULT NULL,
  `exported` TINYINT(1) DEFAULT NULL,
  PRIMARY KEY (`docId`,`indx`),
  KEY `docId` (`docId`),
  KEY `itemCode` (`itemCode`),
  KEY `warehouse` (`warehouse`),
  KEY `vendorCode` (`vendorCode`),
  CONSTRAINT `deliveryreceipt_item_ibfk_3` FOREIGN KEY (`warehouse`) REFERENCES `warehouse` (`code`),
  CONSTRAINT `deliveryreceipt_item_ibfk_4` FOREIGN KEY (`docId`) REFERENCES `deliveryreceipt` (`docId`),
  CONSTRAINT `deliveryreceipt_item_ibfk_1` FOREIGN KEY (`itemCode`) REFERENCES `itemmasterdata` (`itemCode`),
  CONSTRAINT `deliveryreceipt_item_ibfk_2` FOREIGN KEY (`vendorCode`) REFERENCES `businesspartner` (`code`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

CREATE TABLE `inventoryposting` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `docId` VARCHAR(21) NOT NULL,
  `postingDate` DATE NOT NULL,
  `countDateTime` DATETIME NOT NULL,
  `warehouse` VARCHAR(16) NOT NULL,
  `remarks1` VARCHAR(500) DEFAULT NULL,
  `createDate` DATETIME NOT NULL,
  `createdBy` INT(2) NOT NULL,
  `updateDate` DATETIME DEFAULT NULL,
  `updatedBy` INT(2) DEFAULT NULL,
  `exported` TINYINT(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `docId` (`docId`),
  KEY `createdBy` (`createdBy`),
  KEY `updatedBy` (`updatedBy`),
  KEY `warehouse` (`warehouse`),
  CONSTRAINT `inventoryposting_ibfk_1` FOREIGN KEY (`warehouse`) REFERENCES `warehouse` (`code`),
  CONSTRAINT `inventoryposting_ibfk_2` FOREIGN KEY (`createdBy`) REFERENCES `users` (`user_id`),
  CONSTRAINT `inventoryposting_ibfk_3` FOREIGN KEY (`updatedBy`) REFERENCES `users` (`user_id`)
) ENGINE=INNODB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

CREATE TABLE `inventoryposting_item` (
  `docId` VARCHAR(21) NOT NULL,
  `indx` INT(11) NOT NULL,
  `itemCode` VARCHAR(15) NOT NULL,
  `description` VARCHAR(250) DEFAULT NULL,
  `vatable` ENUM('Y','N') NOT NULL,
  `currentQty` DECIMAL(14,6) DEFAULT NULL,
  `countedQty` DECIMAL(14,6) DEFAULT NULL,
  `varianceQty` DECIMAL(14,6) NOT NULL,
  `prchsPrc` DECIMAL(14,6) DEFAULT NULL,
  `retailPrc` DECIMAL(14,6) DEFAULT NULL,
  `exported` TINYINT(1) DEFAULT NULL,
  PRIMARY KEY (`docId`,`indx`),
  KEY `docId` (`docId`),
  KEY `itemCode` (`itemCode`),
  CONSTRAINT `inventoryposting_item_ibfk_1` FOREIGN KEY (`itemCode`) REFERENCES `itemmasterdata` (`itemCode`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;


-- register new modules

INSERT IGNORE INTO documents(documentCode, documentName, lastNo) VALUES('DR', 'Delivery Receipt', 0);
INSERT IGNORE INTO documents(documentCode, documentName, lastNo) VALUES('IP', 'Inventory Posting', 0);


-- create default value for the createDate columns

ALTER TABLE `barcode` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `barcodehistory` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `businesspartner` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `deliveryreceipt` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `export_importfiles` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `goodsreturn` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `grpo` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `inventoryposting` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `inventorytransfer` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `itemmasterdata` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `pricelist` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `pricelisthistory` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `purchaseorder` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `salesinvoice` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `salesreturn` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `transmittedfiles` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `users` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `warehouse` MODIFY COLUMN `createDate` DATETIME DEFAULT CURRENT_TIMESTAMP;